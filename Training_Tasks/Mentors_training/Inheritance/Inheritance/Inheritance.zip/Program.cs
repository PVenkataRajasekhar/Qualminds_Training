﻿namespace Inheritance
{
    public class Program
    {
        
        static void Main(string[] args)
        {
            EnumClass enumClass = new EnumClass();
            enumClass.ReadUserOption();
            try
            {
                Console.Write("Enter your Option :");
                int n = Convert.ToInt32(Console.ReadLine());
                EmployeePosition employeePosition = new Associate();
                employeePosition.EmployeeExperience();
                employeePosition.EmployeeSalary();
                employeePosition.DateOfJoining = DateTime.Now;
                //switch (n)
                //{
                //    case 1:
                //        EmployeePosition employeePosition = new Associate();
                //        employeePosition.EmployeeExperience();
                //        employeePosition.EmployeeSalary();
                //        break;
                //    case 2:
                //        employeePosition = new Junior();
                //        employeePosition.EmployeeExperience();
                //        employeePosition.EmployeeSalary();
                //        break;
                //}
            }
            
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Finally block Executed");
            }
        }
    }
}
