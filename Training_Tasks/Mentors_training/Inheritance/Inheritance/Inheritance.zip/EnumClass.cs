﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class EnumClass
    {
        enum MenuOption
        {
            AssociateSoftWareEngineer = 1,
            JuniorSoftWareEngineer,
            SeniorSoftwareEngineer,
            TechnicalLead,
            Manager,
            CEO
        }
        public void ReadUserOption()
        {
            Console.WriteLine($"Enter {1} for {MenuOption.AssociateSoftWareEngineer}");
            Console.WriteLine($"Enter {2} for {MenuOption.JuniorSoftWareEngineer}");
            Console.WriteLine($"Enter {3} for {MenuOption.SeniorSoftwareEngineer}");
            Console.WriteLine($"Enter {4} for {MenuOption.TechnicalLead}");
            Console.WriteLine($"Enter {5} for {MenuOption.Manager}");
            Console.WriteLine($"Enter {6} for {MenuOption.CEO}");
        }
    }
}
