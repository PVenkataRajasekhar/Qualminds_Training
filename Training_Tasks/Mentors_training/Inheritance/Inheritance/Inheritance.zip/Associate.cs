﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class Associate : EmployeePosition
    {
        
        public override void EmployeeExperience()
        {
            Console.WriteLine("Enter Date Of Joining of the Employee:");
            base.DateOfJoining = Convert.ToDateTime(Console.ReadLine());
            base.EmployeeExperience();
        }
        public override void EmployeeSalary()
        {
            double years = base.Experience.Days / 365D;
            Console.WriteLine("Total years of experience Employee having is : "+years);
            decimal SalaryRange = (years > 1) ? 450000 : 360000;
            Console.WriteLine("Salary range of employee will be around " + SalaryRange);
        }
    }
}
