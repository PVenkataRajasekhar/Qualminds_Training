﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication_Security.Contracts;
using WebApplication_Security.Model;
using System.Threading.Tasks;
using WebApplication_Security.Service;


namespace WebApplication_Security.Controllers
{
    [AllowAnonymous]
    [ApiController]
    [Route("api/Users")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<ActionResult<UserService>> Login(UserModel user)
        {
            var token =await _userService.Login(user);
            if (string.IsNullOrEmpty(token))
            {
                return Unauthorized("Invalid credentials");
            }

            return Ok(new { Token = token });
        }
    }
}

