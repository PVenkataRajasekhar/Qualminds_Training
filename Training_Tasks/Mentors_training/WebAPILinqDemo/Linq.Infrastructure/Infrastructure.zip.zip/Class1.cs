﻿namespace Linq.Infrastructure
{
    public class Class1
    {

    }
}
