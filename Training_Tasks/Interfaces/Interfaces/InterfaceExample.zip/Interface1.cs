﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal interface Interface1
    {
        string Name { get; set; }
        decimal Balance { get; set; }
        void AddAccount();
        public void Withdraw(decimal amount);
        public void Deposit(decimal amount);
    }
}
