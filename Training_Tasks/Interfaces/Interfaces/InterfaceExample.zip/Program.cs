﻿namespace Interfaces
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Transaction transaction = new Transaction();
                transaction.TransactionMethod();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("This is interface program");
            }
        }
    }
}
