﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace Interfaces
{
    abstract class AbstractClass : Interface1
    {
       
        public string Name { get; set; }
        public decimal Balance { get; set; }
        public string SelectAccountType;
        public void AccountType()
        {
            SavingsAccount savings = new SavingsAccount(Name,Balance);
            CurrentAccount current = new CurrentAccount(Name,Balance);
            Console.WriteLine("Enter SavingsAccount for Creating Savings Account,CurrentAccount for creating current Account ");
            SelectAccountType = Console.ReadLine();
            if (SelectAccountType == "SavingsAccount")
            {
                savings.AddAccount();
            }
            else if (SelectAccountType == "CurrentAccount")
            {
                current.AddAccount();
            }
            else
            {
                Console.WriteLine("Enter valid Account name!");
            }
        }
        public abstract void AddAccount();
        public abstract void Withdraw(decimal amount);
        public abstract void Deposit(decimal amount);
    }
}
