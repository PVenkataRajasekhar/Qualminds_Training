﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal class CurrentAccount:AbstractClass
    {
        public CurrentAccount(string name, decimal balance)
        {
            base.Name = name;
            base.Balance = balance;
        }
        public override void AddAccount()
        {
            Console.WriteLine($"current Account Added with name {base.Name} and Balance is {base.Balance}");
        }
        public override void Withdraw(decimal amount)
        {
            Console.WriteLine($"{amount} withdrawn from current account of {base.Name}");
            base.Balance -= amount;
            Console.WriteLine($"Balance of the account is {base.Balance}");
        }
        public override void Deposit(decimal amount)
        {
            Console.WriteLine($"{amount} deposited to current account of {base.Name}");
            base.Balance += amount;
            Console.WriteLine($"Balance of the account is {base.Balance}");
        }
    }
}
