﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    internal class SavingsAccount:AbstractClass
    {
        public SavingsAccount(string name,decimal balance)
        {
            base.Name=name;
            base.Balance = balance;
        }
        public override void AddAccount()
        {
            Console.WriteLine($"Savings Account Added with name {base.Name} and Balance is {base.Balance}");
        }
        public override void Withdraw(decimal amount)
        {
            Console.WriteLine($"{amount} withdrawn from savings account of {base.Name}");
            base.Balance -= amount;
            Console.WriteLine($"Balance of the account is {base.Balance}");
        }
        public override void Deposit(decimal amount)
        {
            Console.WriteLine($"{amount} deposited to savings account of {base.Name}");
            base.Balance += amount;
            Console.WriteLine($"Balance of the account is {base.Balance}");
        }
        public void InterestRate(decimal interest)
        {
            decimal TotalInterest = (base.Balance / (100 * 30)) * interest;
            Console.WriteLine($"Interest for your balance of {base.Balance} per day is {TotalInterest}");
        }
    }
}
