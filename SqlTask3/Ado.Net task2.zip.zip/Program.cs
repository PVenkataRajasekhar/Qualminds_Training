﻿namespace SqlTask3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MenuClass menuClass = new MenuClass();
            menuClass.ReadUserOption();
        }
    }
}
