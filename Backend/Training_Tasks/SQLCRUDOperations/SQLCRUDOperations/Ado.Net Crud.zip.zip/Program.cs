﻿namespace SQLCRUDOperations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MenuClass menuClass = new MenuClass();
            menuClass.ReadUserOption();
        }
    }
}
