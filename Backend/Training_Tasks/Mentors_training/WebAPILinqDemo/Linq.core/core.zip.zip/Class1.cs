﻿namespace Linq.core
{
    public class Class1
    {

    }
}
