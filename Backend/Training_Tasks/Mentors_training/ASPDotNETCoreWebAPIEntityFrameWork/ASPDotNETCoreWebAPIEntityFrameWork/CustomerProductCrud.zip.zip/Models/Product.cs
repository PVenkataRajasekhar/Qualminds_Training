﻿namespace ASPDotNETCoreWebAPIEntityFrameWork.Models
{
    public class Product
    {
        public int Id { get; set; }
        public int ProdID { get; set; }
        public string Name { get; set; }
    }
}
