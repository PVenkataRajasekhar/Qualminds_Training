﻿namespace ASPDotNETCoreWebAPIEntityFrameWork.Models
{
    public class CustomerProducts
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        
    }
}
